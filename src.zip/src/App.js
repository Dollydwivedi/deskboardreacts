import React from 'react';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './component/Home';
import Celender from './component/Calender';
import Help from './component/Help';
import Deshboard from './component/Deshboard';
import Setting from './component/Setting';
import Users from './component/Users';
import Project from './component/Project';
import Sidebar from './component/Sidebar';
import Header from './component/Header'
import './App.css';

function App() {
  return (
    <div className="App">
   <div>
    <BrowserRouter>
    <Header />
    <Sidebar />
    <Routes>
    <Route exact path="/" element={<Home />} />
      <Route exact path="/deshboard" element={<Deshboard />} />
      <Route  exact path="/celender" element={<Celender />} />
        <Route exact path="/help" element={<Help />} />
        <Route exact path="/users" element={<Users />} />
        <Route exact path="/setting" element={<Setting />} />
        <Route exact path="/project" element={<Project />} />
      </Routes>
 </BrowserRouter>
 </div>
    </div>
  );
}
export default App;
