import React from 'react';
function Calender(){
    return(
        <div class="main">
        <h1>Calender</h1>
        </div>
    )
}
export default Calender;