import React from 'react';
function Deshboard(){
    return(
        <div class="main">
        <h1>Deskboard</h1>
        </div>
    )
}
export default Deshboard;