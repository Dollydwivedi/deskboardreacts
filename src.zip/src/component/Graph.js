import {useState} from 'react';
import { Line } from 'react-chartjs-2';
import {Chart as ChartJS, Title, Tooltip, LineElement, Legend, CategoryScale, LinearScale, PointElement, Filler} from 'chart.js';
ChartJS.register(
  Title, Tooltip, LineElement, Legend,
  CategoryScale, LinearScale, PointElement, Filler
)

function Graph() {
  const [data, setData]= useState({
    labels:["Jan","Feb","March","April","May"],
    datasets:[
      {
        label:"Views",
        data:[20, 40, 60, 80, 100, 120, 140],
        backgroundColor:'#5009c4d9',
        borderColor:'blue',
        tension:0.4,
        fill:true,
        pointStyle:'rect',
        pointBorderColor:'blue',
        pointBackgroundColor:'#fff',
        showLine:true
      }
    ]
  })
  return (
    <div className="App gregpapps">
      <Line data={data}></Line>
    </div>
  );
}

export default Graph;