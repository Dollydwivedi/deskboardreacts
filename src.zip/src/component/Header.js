import React from 'react';

import { MdNotifications } from 'react-icons/md';

function Header() {
    return (
      <div className="header">
       <MdNotifications className="headericons"/>
      </div>
    );
  }
  export default Header;

