import React from 'react';
function Help(){
    return(
        <div class="main">
        <h1>Help</h1>
        </div>
    )
}
export default Help;