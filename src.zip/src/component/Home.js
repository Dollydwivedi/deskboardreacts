import React from 'react';
import { Link } from 'react-router-dom';
import { MdOutlineArrowForwardIos } from 'react-icons/md';
import { AiFillStar } from 'react-icons/ai';
import {AiOutlinePlus} from 'react-icons/ai';
import { GrLike } from 'react-icons/gr';
import { AiFillHeart } from 'react-icons/ai';
import {BsFillEmojiSmileFill} from 'react-icons/bs';
import { AiTwotoneAppstore } from 'react-icons/ai';

import contactus from '../assets/contactus.jpg';
import Progressbar from '../component/Progressbar'
import Graph from '../component/Graph';
function Home(){
    return(
        <div>
        <div className="main">
        
        <div className='container'>
       
        <div className='row'>
        <div className="col-md-4 col-sm-12">
       <div className="hmtext">
        <div className='headtest'>
        <h3>Hi John,</h3>
        <p className="wlcms">Welcome back!</p>
        <p className="wlcmstexts">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do 
        eiusmod tempor incididunt ut labore et dolore magna aliqua. 
        </p>
       
        </div>
        <div className='imghomes'>
         <img src={contactus} className='imgconts' alt=''/>
        </div>
        <div className='cardshome'>
        <div className="cardicons">
        <div className="starticons"> <AiFillStar className="icons"/></div>
         <h5>Contgratulations John</h5>
         <p>You have completed 75% of your profile. Your current progress is grest</p>
         <Link to="/" className='viewprofiles'>View Profile</Link>
        </div>
        </div>
       </div>
        </div>
        <div class="col-md-4 col-sm-12">
        <div className='grphsaa-abs'>
          <div className="graphsa">
          <div className='textmessg'>
        <div className="icons-mssg ">
        <div className="likrsee">
        <GrLike className='imgconts-likes' />
        </div>
        <div className="text-imassg">
        <h6 className="liks">1234567</h6>
        <p className='nubnnokd'>Likes</p>
         </div>
        </div>
        <div className="dropmassg">
        <MdOutlineArrowForwardIos />
        </div>
        </div>
        <div className='textmessg'>
        <div className="icons-mssg ">
        <div className="harts">
        <AiFillHeart className='imgconts-harts' />
        </div>
        <div className="text-imassg">
        <h6 className="liks">2345</h6>
        <p className='nubnnokd'>Love</p>
         </div>
        </div>
        <div className="dropmassg">
        <MdOutlineArrowForwardIos />
        </div>
        </div>
        <div className='textmessg'>
        <div className="icons-mssg ">
        <div className="smailss">
        <BsFillEmojiSmileFill className='imgconts-smile' />
        </div>
        <div className="text-imassg">
        <h6 className="liks">4567888</h6>
        <p className='nubnnokd'>Smiles</p>
         </div>
        </div>
        <div className="dropmassg">
        <MdOutlineArrowForwardIos />
        </div>
        </div>
         </div>
         <div className='grphsaa'>
         <Graph />
         <div className='graphviews'>
         <div className='textmessg'>
        <div className="icons-mssg">
        <div className='viewsdeska'>
        <AiTwotoneAppstore className='icons-views'/>
        </div>
        <div className="text-imassg">
        <h6 className="liksviewsss">View Dashboard</h6>
       
         </div>
        </div>
        <div className="dropmassg">
        <MdOutlineArrowForwardIos />
        </div>
        </div>
         </div>
         </div>
         </div>
        </div>
        <div className="col-md-4 col-sm-12">
        <div className='targets'>
        <h3 className="textmges">Targets</h3>
        <Progressbar/>
        </div>
         <div className='textmessg-a'>
         <h3 className="textmges">Message</h3>
        <div className='textmessg'>
        <div className="icons-mssg">
        <img src={contactus} className='imgconts-msg' alt=''/>
        <div className="text-imassg">
        <h6 className="liks">Emmy Anderson</h6>
        <p className='nubnnokd'>8:00 - 10:00</p>
         </div>
        </div>
        <div className="dropmassg">
        <MdOutlineArrowForwardIos />
        </div>
        </div>
        <div className='textmessg'>
        <div className="icons-mssg">
        <img src={contactus} className='imgconts-msg' alt=''/>
        <div className="text-imassg">
        <h6 className="liks">Emmy Anderson</h6>
        <p className='nubnnokd'>8:00 - 10:00</p>
         </div>
        </div>
        <div className="dropmassg">
        <MdOutlineArrowForwardIos />
        </div>
        </div>
        <div className='textmessg'>
        <div className="icons-mssg">
        <img src={contactus} className='imgconts-msg' alt=''/>
        <div className="text-imassg">
        <h6 className="liks">Emmy Anderson</h6>
        <p className='nubnnokd'>8:00 - 10:00</p>
         </div>
        </div>
        <div className="dropmassg">
        <MdOutlineArrowForwardIos />
        </div>
        </div>
        <div className="testapps">
         <div> <AiOutlinePlus /></div>
        </div>
       </div>
        </div>
        </div>
        </div>
        </div>
        </div>
       
    )
}
export default Home;