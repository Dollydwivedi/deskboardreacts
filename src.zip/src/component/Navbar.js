import React from 'react';
import { Link } from 'react-router-dom';
import { AiFillHome } from 'react-icons/ai';
import { FaUserFriends } from 'react-icons/fa';
import { RiProjectorLine } from 'react-icons/ri';
import { AiOutlineSetting } from 'react-icons/ai';
import { SlCalender } from 'react-icons/sl';
import { GiHelp } from 'react-icons/gi';
import { BsWindowDesktop } from 'react-icons/bs';
import './style.css';
function Navbar() {
    return (
      <div>
      <div id="basic-navbar-nav-s" className="navbarsides">
        <ul className="navbass" >
        <li><Link to="/home" className='navbarss'><AiFillHome />Home</Link></li>
        <li><Link to="/deshboard" className='navbarss'><BsWindowDesktop />Deshboard</Link></li>
        <li><Link to="/users" className='navbarss' ><FaUserFriends />Users</Link></li>
        <li><Link to="/calender" className='navbarss'><SlCalender/>Calender</Link></li>
       <li><Link to="/project" className='navbarss'><RiProjectorLine />Project</Link></li> 
        <li><Link to="/help" className='navbarss' ><GiHelp />Help</Link></li>
       <li><Link to="/setting" className='navbarss lastbottoms'><AiOutlineSetting />Setting</Link></li> 
       </ul>
      
      </div>
      </div>
    );
  }
  export default Navbar;

