import React from 'react';
import ProgressBar from 'react-bootstrap/ProgressBar';
function Progressbar(){
  
    return(
        <div className="Progressa">
        <div className="progresstexts">
        <div className='labelstexts'>
        <p>Views</p>
        <p>75%</p>
        </div>
        <ProgressBar striped variant="primary" now={75} className='pregsaa' />
        </div>
        <div className="progresstexts">
        <div className='labelstexts'>
        <p>Followers</p>
        <p>50%</p>
        </div>
        <ProgressBar striped variant="warning" now={50} className='pregsaa' />
        </div>
        <div className="progresstexts">
        <div className='labelstexts'>
        <p>Income</p>
        <p>25%</p>
        </div>
        <ProgressBar striped variant="danger" now={25} className='pregsaa' />
        </div>
        </div>
    )
}
export default Progressbar;