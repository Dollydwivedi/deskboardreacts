import React from 'react';
function Project(){
    return(
        <div class="main">
        <h1>Project</h1>
        </div>
    )
}
export default Project;