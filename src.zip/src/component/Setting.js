import React from 'react';
function Setting(){
    return(
        <div class="main">
        <h1>Setting</h1>
        </div>
    )
}
export default Setting;