import React from 'react';
import { Link } from 'react-router-dom';
import { AiOutlineBars } from 'react-icons/ai';
import { AiFillHome } from 'react-icons/ai';
import { FaUserFriends } from 'react-icons/fa';
import { RiProjectorLine } from 'react-icons/ri';
import { AiOutlineSetting } from 'react-icons/ai';
import { SlCalender } from 'react-icons/sl';
import { GiHelp } from 'react-icons/gi';
import { BsWindowDesktop } from 'react-icons/bs';
import './style.css';
function Sidebar() {
    return (
      <div>
      <div id="basic-navbar-nav-s" className="navbarsides">
    
      <AiOutlineBars className="togglesbuttons" />
     
      <ul className="navbass" >
        <li className='active'><Link to="/" className='navbarss'><AiFillHome /> <span className="sidebarmble">Home</span></Link></li>
        <li><Link to="/deshboard" className='navbarss'><BsWindowDesktop /><span className="sidebarmble">Deshboard</span></Link></li>
        <li><Link to="/users" className='navbarss' ><FaUserFriends /><span className="sidebarmble">Users</span></Link></li>
        <li><Link to="/calender" className='navbarss'><SlCalender/><span className="sidebarmble">Calender</span></Link></li>
       <li><Link to="/project" className='navbarss'><RiProjectorLine /><span className="sidebarmble">Project</span></Link></li> 
        <li><Link to="/help" className='navbarss' ><GiHelp /><span className="sidebarmble">Help</span></Link></li>
       <li><Link to="/setting" className='navbarss lastbottoms'><AiOutlineSetting /><span className="sidebarmble">Setting</span></Link></li> 
       </ul>
      
      </div>
      </div>
    );
  }
  export default Sidebar;

