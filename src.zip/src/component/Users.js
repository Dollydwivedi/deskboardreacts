import React from 'react';
function Users(){
    return(
        <div class="main">
        <h1>Users</h1>
        </div>
    )
}
export default Users;